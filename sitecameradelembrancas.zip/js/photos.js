/* ============================================================
   CONFIGURAÇÃO DAS FOTOS (Google Drive)
   ============================================================

   Como funciona: cada foto fica no Google Drive, compartilhada
   como "Qualquer pessoa com o link pode ver". O site monta a URL
   de miniatura do Drive a partir do ID de cada arquivo:

     https://drive.google.com/thumbnail?id=ID_DO_ARQUIVO&sz=w600

   Para gerar a lista abaixo automaticamente com as 900+ fotos,
   use o script docs/tools/exportar-fotos.gs (instruções no
   docs/README.md). Ele percorre uma pasta inteira do Drive,
   libera o compartilhamento por link e gera este arquivo pronto.

   Enquanto a lista estiver vazia, o site usa fotos de demonstração
   para você poder testar tudo.
   ============================================================ */

const DRIVE_PHOTO_IDS = [
  // "1AbCdEfGhIjKlMnOpQrStUvWxYz1234567",
  // "1ZyXwVuTsRqPoNmLkJiHgFeDcBa7654321",
];

/* URL principal (miniatura do Drive — rápida e funciona em <img>) */
function drivePhotoUrl(id, size) {
  return "https://drive.google.com/thumbnail?id=" + id + "&sz=w" + (size || 600);
}

/* URL alternativa (CDN do Google) usada se a principal falhar */
function drivePhotoFallbackUrl(id, size) {
  return "https://lh3.googleusercontent.com/d/" + id + "=w" + (size || 600);
}

/* Fotos de demonstração (geradas na hora) para quando a lista está vazia:
   gradientes escuros de roxo e verde com luzes desfocadas (bokeh) */
function makePlaceholderPhotos(count) {
  const photos = [];
  for (let i = 0; i < count; i++) {
    const c = document.createElement("canvas");
    c.width = 300; c.height = 300;
    const ctx = c.getContext("2d");
    const g = ctx.createLinearGradient(0, 0, 300, 300);
    const hueA = 262 + Math.random() * 22;
    const hueB = 75 + Math.random() * 20;
    g.addColorStop(0, "hsl(" + hueA + ", 60%, " + (8 + Math.random() * 8) + "%)");
    g.addColorStop(1, "hsl(" + (Math.random() < 0.5 ? hueB : hueA) + ", 55%, " + (12 + Math.random() * 10) + "%)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 300, 300);
    const lights = 6 + (Math.random() * 8) | 0;
    for (let j = 0; j < lights; j++) {
      const x = Math.random() * 300, y = Math.random() * 300;
      const r = 8 + Math.random() * 36;
      const hue = Math.random() < 0.5 ? hueA : hueB;
      const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
      rg.addColorStop(0, "hsla(" + hue + ", 90%, 70%, " + (0.35 + Math.random() * 0.4) + ")");
      rg.addColorStop(1, "hsla(" + hue + ", 90%, 70%, 0)");
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
    photos.push(c.toDataURL("image/jpeg", 0.8));
  }
  return photos;
}
